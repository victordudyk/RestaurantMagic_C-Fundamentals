﻿namespace Lesson3
{
    using System;
    using System.Collections.Generic;

    using Lesson3.Sources;

    class Program
    {
        static void Main(string[] args)
        {
            Customer johnT = new Customer("John", "T", 22, "London", DiscountType.Medium);

            var bread = new Product("Bread", 10.2, ProductType.Bakery);
            var meat = new Product("Meat", 100.2, ProductType.Meats);
            var alcohol = new Product("Alcohol", 100.2, ProductType.Alcohol);

            var purchaseBread = new Purchase(bread, 3);
            var purchaseMeat = new Purchase(meat, 3.7);
            var purchaseAlcohol = new Purchase(alcohol, 1);

            var purchases = new List<Purchase>();
            purchases.Add(purchaseBread);
            purchases.Add(purchaseMeat);
            purchases.Add(purchaseAlcohol);
            
            var order = new Order(purchases, johnT);
           

            // for
            var sumOfDiscount = 0.0;
            var discountCalculator = new DiscountCalculator();
            for (var i = 0; i < purchases.Count; i++)
            {
                sumOfDiscount += discountCalculator.Calculate(purchases[i].Product.Price, johnT.DiscountType);
            }
            Console.WriteLine($"for.sumOfDiscount: {sumOfDiscount}");
            
            // foreach
            sumOfDiscount = 0.0;
            foreach (Purchase purchase in purchases)
            {
                sumOfDiscount += discountCalculator.Calculate(purchase.Product.Price, johnT.DiscountType);
            }
            Console.WriteLine($"foreach.sumOfDiscount: {sumOfDiscount}");
            
            //while
            sumOfDiscount = 0.0;
            var index = 0;
            while (index < purchases.Count)
            {
                sumOfDiscount += discountCalculator.Calculate(purchases[index].Product.Price, johnT.DiscountType);
                index++;
            }
            Console.WriteLine($"while.sumOfDiscount: {sumOfDiscount}");

            // do while
            sumOfDiscount = 0.0;
            var count = purchases.Count-1;
            do
            {
                sumOfDiscount += discountCalculator.Calculate(purchases[count].Product.Price, johnT.DiscountType);
                count--;
            }
            while (count >= 0);
            Console.WriteLine($" do while.sumOfDiscount: {sumOfDiscount}");
            Console.Read();
        }
    }
}
