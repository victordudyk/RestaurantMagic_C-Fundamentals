﻿namespace Lesson3.Sources
{
    using System;

    public class Customer
    {
        public Customer(string firstName, string lastName, int age, string address, DiscountType discountType)
        {
            FirstName = firstName;
            LastName = lastName;
            DateOfRegistration = DateTime.Now;
            Address = address;
            Age = age;
            DiscountType = discountType;
        }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public int Age { get; set; }

        public DateTime DateOfRegistration { get;  }

        public DiscountType DiscountType { get; set; }

        protected string Address { get; set; }

        protected string MobileNumber { get; set; }
    }
}