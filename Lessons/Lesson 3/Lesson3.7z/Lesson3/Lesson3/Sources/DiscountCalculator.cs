﻿namespace Lesson3.Sources
{
    using System;

    public class DiscountCalculator
    {
        public double Calculate(double price, DiscountType discountType)
        {
            return price * (100 - GetDiscountPercent(discountType)) / 100;
        }

        private int GetDiscountPercent(DiscountType discountType)
        {
            /*if (discountType == DiscountType.Low)
            {
                return 3;
            }
            else if (discountType == DiscountType.Medium)
            {
                return 5;
            }
            else if (discountType == DiscountType.High)
            {
                return 7;
            }
            return 0;*/

            switch (discountType)
            {
                case DiscountType.Low:
                    return 3;
                case DiscountType.Medium:
                    return 5;
                case DiscountType.High:
                    return 7;
                case DiscountType.None:
                    return 0;
                default:
                    throw new ArgumentOutOfRangeException(nameof(discountType), discountType, null);
            }
        }
    }
}