﻿namespace Lesson3.Sources
{
    public enum DiscountType
    {
        None,
        Low,
        Medium,
        High
    }
}