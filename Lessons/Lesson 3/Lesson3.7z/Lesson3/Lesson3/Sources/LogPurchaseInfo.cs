﻿namespace Lesson3.Sources
{
    public delegate void LogPurchaseInfo(Purchase purchase);
}