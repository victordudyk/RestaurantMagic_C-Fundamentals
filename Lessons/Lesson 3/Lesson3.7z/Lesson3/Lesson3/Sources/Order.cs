﻿namespace Lesson3.Sources
{
    using System;
    using System.Collections.Generic;

    public class Order
    {
        public event EventHandler PurchaseAdded;

        public Order(List<Purchase> purchases, Customer customer)
        {
            Customer = customer;
            Purchases = purchases;
            Date = DateTime.Today;
            PurchaseAdded += OnPurchaseAdded;
        }
        
        public List<Purchase> Purchases { get; set; }

        public Customer Customer { get; set; }

        public DateTime Date { get; }

        public bool IsTodayOrder()
        {
            return Date == DateTime.Today;
        }

        public void AddPurchase(Purchase purchase)
        {
            Purchases.Add(purchase);
            OnPurchaseAdded(EventArgs.Empty);
        }

        public void OnPurchaseAdded(object sender, EventArgs e)
        {
            Console.WriteLine("Purchase added!");
        }

        protected virtual void OnPurchaseAdded(EventArgs e)
        {
            EventHandler handler = PurchaseAdded;
            handler?.Invoke(this, e);
        }
    }
}