﻿namespace Lesson3.Sources
{
    public class Product
    {
        public Product(string name, double price, ProductType productType)
        {
            Name = name;
            Price = price;
            ProductType = productType;
        }

        public static double DefaultAmount { get; set; } = 1.00;

        public string Name { get; set; }

        public double Price { get; set; }

        public ProductType ProductType { get; set; }
    }
}