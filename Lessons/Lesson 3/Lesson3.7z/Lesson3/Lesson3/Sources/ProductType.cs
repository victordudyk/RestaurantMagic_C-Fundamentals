﻿namespace Lesson3.Sources
{
    public enum ProductType
    {
        Bakery,
        Meats,
        Alcohol, 
        Snacks,
        BabyFoods,
        DietFoods,
        Other
    }
}