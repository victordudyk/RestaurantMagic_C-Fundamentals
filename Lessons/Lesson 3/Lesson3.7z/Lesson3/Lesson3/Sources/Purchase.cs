﻿namespace Lesson3.Sources
{
    public class Purchase
    {
        public Purchase(Product product, double amount)
        {
            Product = product;
            Amount = amount;
        }

        public Product Product { get; set; }

        public double Amount { get; set; }

        public double Calculate()
        {
            return Amount * Product.Price;
        }

        public string Summarize()
        {
            return $"{Product.Name}, Price: {Product.Price}, Amount: {Amount}";
        }
    }
}